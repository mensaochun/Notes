#include <stdio.h>
#include "other.h"

int Other()
{
	printf("Other thing...\n");
	return 0;
}
int Example(int a,int b)
{
	return a + b;
}
