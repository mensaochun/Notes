#include <stdio.h>
#include "../object/object.h"

int main()
{
	Object obj;
	obj.a = 1;
	obj.b = 2;
	Test(&obj);
	return 0;
}