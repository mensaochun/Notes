  
struct Object
{
	int a;
	int b;    
};

int Test(Object* obj);
