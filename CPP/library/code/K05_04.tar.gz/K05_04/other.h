  
  
int Other();
int Example(int a,int b);