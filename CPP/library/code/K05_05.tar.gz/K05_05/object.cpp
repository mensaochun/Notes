#include <stdio.h>
#include "object.h"
 
int Test(Object* obj)
{
	printf("a: %d, b: %d \n", obj->a, obj->b);
	return 0; 
}

