#include <stdio.h>
#include "other.h"

int main()
{
	Other();
	
	int result = Example(10, 11);
	printf("result: %d \n", result);
	return 0;
}