
#include <stdio.h>

extern "C" {
void example(int a, int b);
}

int main()
{
	example(1,2);
	return 0;
}

