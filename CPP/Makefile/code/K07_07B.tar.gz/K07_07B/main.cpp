
#include <stdio.h>

#include "build/example.h"

int main()
{
	example(1,2);
	return 0;
}

