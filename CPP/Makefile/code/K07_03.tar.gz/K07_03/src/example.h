
class Object
{
public:
	void Test();
	int id;
};

int example(int a, int b);

