
#include <stdio.h>
#include "example.h"

int example(int a, int b)
{
	printf("example library: a=%d, b=%d \n", a, b);
	return 0;
}

void Object::Test()
{
	printf("id=%d \n", id);
}


