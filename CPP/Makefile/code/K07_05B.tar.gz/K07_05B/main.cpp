
#include "../K07_05A/test1.h"
#include "../K07_05A/test2.h"

int main()
{
	test1();
	test2();
	return 0;
}

