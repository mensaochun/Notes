#include <stdio.h>

void test1()
{
	printf("test1....... shared\n");
}

