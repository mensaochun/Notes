#include <stdio.h>

void test2()
{
	printf("test2.......\n");
}

