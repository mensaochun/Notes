
#include "example.h"

int main()
{
	example(1,2);
	return 0;
}

